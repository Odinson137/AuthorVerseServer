CREATE PROCEDURE AddForumMessage @BookId INT, @UserId NVARCHAR(255), @ParrentMessageId INT NULL, @Text NVARCHAR(MAX), @SendTime DATETIME, @MessageId INT OUTPUT AS BEGIN    INSERT INTO ForumMessages (BookId, UserId, ParrentMessageId, Text, SendTime)    VALUES (@BookId, @UserId, @ParrentMessageId, @Text, @SendTime)    SET @MessageId = SCOPE_IDENTITY(); END;
go

